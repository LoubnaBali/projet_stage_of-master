<?php
include "connect.php";

$id_client = $_GET["id"];
$statut_cl = $_GET["statut"];

if ($statut_cl == "client") 
    {
        $req = "UPDATE clients SET statut_cl = 'apprenant' WHERE id_cl = ?";
        $maj=connexion()->prepare($req);
        $maj->execute(array($id_client)); 
        header('Location: affichage-clients.php');
    } 
else 
    {
        $req = "UPDATE clients SET statut_cl = 'client' WHERE id_cl = ?";
        $maj=connexion()->prepare($req);
        $maj->execute(array($id_client)); 
        header('Location: affichage-clients.php');
    }
?>