<?php
require_once"connect.php";

//fonction affichage des financeur
function affichage_financeur(){
    try{
        $co=connexion();
        $sql= 'SELECT * FROM `financeur`';
        $affichage_financeur=$co->prepare($sql);
        $affichage_financeur->execute();
        return $affichage_financeur;
    }
    catch(PDOException $e){
        echo 'Erreur: ' .$e-getMessage();
    }
    finally{
        $co=null;
    }

}
?>