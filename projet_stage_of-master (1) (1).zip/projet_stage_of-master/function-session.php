<?php
require_once'connect.php';
//fonction affichage session
function affichage_session(){
    try{
        $co=connexion();
        $sql='SELECT * FROM `session`';
        $affichage_session=$co->prepare($sql);
        $affichage_session->execute();
        return $affichage_session;
    }catch(PDOException $e){
        echo'Erreur :' .$e->getMessage();
    }finally{
        $co=null;
    }
}

?>