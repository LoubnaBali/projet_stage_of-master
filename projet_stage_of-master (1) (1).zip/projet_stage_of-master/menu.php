<!doctype html>
<html class="no-js" lang="">

<body>

    <!-- Main Menu area start-->
    <div class="main-menu-area mg-tb-40">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <ul class="nav nav-tabs notika-menu-wrap menu-it-icon-pro">
                        <!-- <li class="active"><a data-toggle="tab" href="#Home">Accueil</a>
                        </li> -->
                        <li><a data-toggle="tab" href="#mailbox">Client</a>
                        </li>
                        <li><a data-toggle="tab" href="#Interface">Financeurs</a>
                        </li>
                        <li><a data-toggle="tab" href="#formateurs">Formateurs</a>
                        </li>
                        <!-- <li><a data-toggle="tab" href="#Charts"><i class="notika-icon notika-bar-chart"></i> Charts</a>
                        </li>
                        <li><a data-toggle="tab" href="#Tables"><i class="notika-icon notika-windows"></i> Tables</a>
                        </li>
                        <li><a data-toggle="tab" href="#Forms"><i class="notika-icon notika-form"></i> Forms</a>
                        </li>
                        <li><a data-toggle="tab" href="#Appviews"><i class="notika-icon notika-app"></i> App views</a>
                        </li>
                        <li><a data-toggle="tab" href="#Page"><i class="notika-icon notika-support"></i> Pages</a>
                        </li> -->
                    </ul>
                    <div class="tab-content custom-menu-content">
                        <div id="Home" class="tab-pane in active notika-tab-menu-bg animated flipInX">
                            <ul class="notika-main-menu-dropdown">
                                <!-- <li><a href="index.html">Dashboard One</a>
                                </li>
                                <li><a href="index-2.html">Dashboard Two</a>
                                </li>
                                <li><a href="index-3.html">Dashboard Three</a>
                                </li>
                                <li><a href="index-4.html">Dashboard Four</a>
                                </li>
                                <li><a href="analytics.html">Analytics</a>
                                </li>
                                <li><a href="widgets.html">Widgets</a>
                                </li> -->
                            </ul>
                        </div>
                        <div id="mailbox" class="tab-pane notika-tab-menu-bg animated flipInX">
                            <ul class="notika-main-menu-dropdown">
                                <li><a href="affichage-clients.php">Liste des dossiers</a>
                                </li>
                                <li><a href="affichage-apprenants.php">Apprenants</a>
                                </li>
                                <li><a href="nouveau-client.php">Ajouter un client</a>
                                </li>
                            </ul>
                        </div>
                        <div id="Interface" class="tab-pane notika-tab-menu-bg animated flipInX">
                            <ul class="notika-main-menu-dropdown">
                                <li><a href="affichage-financeurs.php">Liste des financeurs</a>
                                </li>
                                <li><a href="nouveau-financeurs.php">Ajouter un financeurs</a>
                                </li>
                            </ul>
                        </div>
                        <div id="formateurs" class="tab-pane notika-tab-menu-bg animated flipInX">
                            <ul class="notika-main-menu-dropdown">
                                <!-- <li><a href="affichage-financeurs.php">Liste des financeurs</a>
                                </li>
                                <li><a href="nouveau-financeurs.php">Ajouter un financeurs</a>
                                </li> -->
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Main Menu area End-->


</body>

</html>