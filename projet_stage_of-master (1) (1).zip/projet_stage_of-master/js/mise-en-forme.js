
let dimension = document.getElementsByTagName("td").length;
// console.log(dimension);

let index = 10;

for (index; index < dimension; index = index + 12) 
    {
        // console.log(index);

        let mybody = document.getElementsByTagName("td")[index];
        let mybody_text = mybody.innerHTML;
        console.log(mybody);
        console.log(mybody_text);


   switch (mybody_text) {
        case " refuser ":
            document.getElementsByTagName("td")[index].style.color = "red";
            break;
        case " à traiter ":
            document.getElementsByTagName("td")[index].style.color = "orange";
            break;
        case " en cours ":
            document.getElementsByTagName("td")[index].style.color = "green";
            break;
    }



    }


 