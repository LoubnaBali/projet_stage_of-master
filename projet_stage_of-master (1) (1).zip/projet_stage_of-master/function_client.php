<?php 

require_once"connect.php";

//Vérification de l'envoie du formulaire 
if(isset($_POST['formclient'])){
  try{
    $co=connexion();
    //stockage des informations du formulaire dans des variables
    $sexe = $_POST['sexe'];
    $nom =$_POST['nom'];
    $prenom = $_POST['prenom'];
    $datenaissance=$_POST['datenaissance'];
    $telephone =$_POST['telephone'];
    $email = $_POST['email'];
    $adresse =$_POST['adresse'];
    $codepostal =$_POST['codepostal'];
    $ville =$_POST['ville'];
    $financeur =$_POST['financeur'];
    $etat =$_POST['etat'];
    $formation = $_POST['formation'];

    if(!empty($_POST['nom']) AND !empty($_POST['prenom']) AND !empty($_POST['datenaissance']) AND !empty($_POST['telephone']) AND !empty($_POST['email']) AND !empty($_POST['adresse']) AND !empty($_POST['codepostal']) AND !empty($_POST['ville']) AND !empty($_POST['financeur']) AND !empty($_POST['etat']) AND !empty($_POST['formation'])){
      //insertion dans la table financement
      $sql='INSERT INTO `financement`(id_financeur, etat_financement) VALUES (:financeur, :etat)';
      $insert=$co->prepare($sql);
      $insert -> bindParam(':financeur', $financeur);
      $insert -> bindParam(':etat', $etat);
      $insert ->execute();
      $id_financement=$co->lastInsertId();

      //insertion dans la table client
      $sql2='INSERT INTO `clients`(id_financement, id_session, nom_cl, prenom_cl, date_naiss_client, tel_cl, email_cl, sexe_cl, adresse_cl, cp_cl, ville_cl, statut_cl) VALUES (:idf, :ids, :nom, :prenom, :naiss, :tel, :email, :sexe, :adresse, :cp, :ville, "client")';
      $insert2=$co->prepare($sql2);
      $insert2 -> bindParam(':idf', $id_financement);
      $insert2 -> bindParam(':ids', $formation);
      $insert2 -> bindParam(':nom', $nom);
      $insert2 -> bindParam(':prenom', $prenom);
      $insert2 -> bindParam(':naiss', $datenaissance);
      $insert2 -> bindParam(':tel', $telephone);
      $insert2 -> bindParam(':email', $email);
      $insert2 -> bindParam(':sexe', $sexe);
      $insert2 -> bindParam(':adresse', $adresse);
      $insert2 -> bindParam(':cp', $codepostal);
      $insert2 -> bindParam(':ville', $ville);
      $insert2->execute();
      header('location:affichage-clients.php');    
    }else{
      header('location:nouveau-client.php?erreur=1');
    }
  }catch(PDOException $e){
    echo"Erreur :" .$e->getMessage();
  }finally{
    $co=null;
  }

}

//Fonction nombre de client à traiter
function client_a_traiter(){
  try{
    $co=connexion();
    $sql="SELECT `clients`.*, `financement`.`etat_financement` FROM `clients` LEFT JOIN `financement` ON `clients`.`id_financement` = `financement`.`id_financement` WHERE `financement`.`etat_financement` = 'à traiter'";
    $client_a_traiter=$co->prepare($sql);
    $client_a_traiter->execute();
    return $client_a_traiter;
  }catch(PDOException $e){
    echo"erreur : " .$e->getMessage();
  }finally{
    $co=null;
  }
}
//Fonction nombre de client en cours
function client_encours(){
  try{
    $co=connexion();
    $sql="SELECT `clients`.*, `financement`.`etat_financement` FROM `clients` LEFT JOIN `financement` ON `clients`.`id_financement` = `financement`.`id_financement` WHERE `financement`.`etat_financement` = 'en cours'";
    $client_encours=$co->prepare($sql);
    $client_encours->execute();
    return $client_encours;
  }catch(PDOException $e){
    echo"erreur : " .$e->getMessage();
  }finally{
    $co=null;
  }
}
//Fonction nombre de client refusé
function client_refuse(){
  try{
    $co=connexion();
    $sql="SELECT `clients`.*, `financement`.`etat_financement` FROM `clients` LEFT JOIN `financement` ON `clients`.`id_financement` = `financement`.`id_financement` WHERE `financement`.`etat_financement` = 'refusé'";
    $client_refuse=$co->prepare($sql);
    $client_refuse->execute();
    return $client_refuse;
  }catch(PDOException $e){
    echo"erreur : " .$e->getMessage();
  }finally{
    $co=null;
  }
}


?>